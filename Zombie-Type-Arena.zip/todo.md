# Integration TODO

## ZIP delivery

- [ ] Validate the complete project and create a downloadable ZIP archive for manual GitHub upload.

## GitHub and footer update

- [x] Confirm the GitHub repository destination: `https://github.com/akshaynam3e/versantpro.in/`.
- [ ] Add a footer link labeled `game` that opens the game page in the existing `akshaynam3e/versantpro.in` source.
- [ ] Validate the complete project and upload all required files to `akshaynam3e/versantpro.in`.

- [x] Obtain the existing website URL and homepage source content; repository/backend source is still unavailable.
- [x] Inspect the available homepage source: static HTML/CSS, Firebase Auth client SDK, dark black/cyan visual system, and an existing `game.html` navigation link.
- [x] Use the existing `game.html` destination as the integration route, keeping the page authenticated through the existing Firebase Auth guard.
- [x] Implement private rooms, random matchmaking entry, live opponent presence wiring, 60-second scoring, results, and restart within the integrated game page.
- [x] Verify the game lobby visually on desktop, run TypeScript validation, and confirm responsive CSS rules are included; authenticated production-site integration still requires the full source deployment context.
