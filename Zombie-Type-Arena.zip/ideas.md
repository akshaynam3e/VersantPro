# Zombie Type Arena — Design Direction

## Three stylistic approaches

### Theme Name: Deadbolt Terminal
Very brief intro: A tense, industrial command-center interface where every typed word feels like a defensive action. Rust, phosphor green, and warning amber create a tactile survival-console mood.
Probability: 0.07

### Theme Name: Graveyard Carnival
Very brief intro: A mischievous arcade visual language with hand-painted signage, candy-bright threat colors, and theatrical zombie silhouettes. It feels playful, social, and immediately readable.
Probability: 0.03

### Theme Name: Night Shift Dispatch
Very brief intro: A cinematic midnight operations room with paper notes, red incident stamps, and a warm desk-lamp glow. The experience feels focused, competitive, and slightly noir.
Probability: 0.08

## Selected approach: Deadbolt Terminal

### Design Movement
Industrial brutalism blended with tactile retro-computing and survival-horror game UI. The interface should feel like a fortified console assembled from steel plates, warning labels, phosphor displays, and operator notes.

### Core Principles
1. **Threat is legible:** timers, incoming words, health, and opponent state have clear visual priority.
2. **Tactile utility:** surfaces feel machined and handled, using hard edges, stamped labels, scanlines, and restrained texture rather than decorative gradients.
3. **Asymmetric command layout:** the arena is the dominant field, while metrics and controls dock like equipment panels around it.
4. **Social pressure:** the opponent is always visible as a live parallel signal, never hidden behind a separate page.

### Color Philosophy
The base is near-black blue steel to reduce visual noise and make the active word glow readable. Phosphor green marks successful control and player momentum; hazard amber signals countdown pressure; oxidized red is reserved for damage, missed words, and the zombie threat. The signature brand color is **toxic mint #B9FF72**, a high-visibility phosphor tone that feels like an emergency monitor brought back to life.

### Layout Paradigm
A wide command console with a left-side identity rail, central falling-word arena, and right-side rival telemetry panel. On narrow screens, the rail becomes a compact status strip and the telemetry panel stacks below the arena. The primary typing field stays visually attached to the bottom edge of the arena like a control bay.

### Signature Elements
- A segmented **60-second countdown ring** with amber warning ticks.
- **Hazard tape separators** and stamped micro-labels such as LIVE FEED, TARGET LOCK, and MATCH ID.
- A rival “signal trace” with a moving phosphor line and compact combat metrics.

### Interaction Philosophy
Every action should confirm instantly. Typing is the primary interaction, so the input stays focused and has a strong active state. Buttons feel like physical toggles with a brief press-in response. Matchmaking states communicate progress through operational language—“Scanning channels,” “Room secured,” and “Signal acquired”—rather than generic loading text.

### Animation
Use quick 120–220ms transitions for controls, progress, and status changes. Words descend with smooth linear motion and slight drift, while a correctly typed word snaps into a brief mint impact burst and a miss produces a short red jitter. The countdown shifts from steady to urgent during the final ten seconds. Respect reduced-motion preferences by disabling drift, bursts, and scanline movement.

### Typography System
Use **Barlow Condensed** for display labels, counters, and match metrics; use **IBM Plex Mono** for typed words, room codes, telemetry, and body copy. Headlines are uppercase with tight tracking. Supporting copy uses sentence case and generous line height. Avoid Inter and generic system-font presentation.

### Brand Essence
Zombie Type Arena is a live-fire typing duel for people who want a fast, readable way to test their reflexes against a friend or a stranger. It is direct, tense, and social.

Personality adjectives: **kinetic, industrial, mischievous**.

### Brand Voice
Headlines sound like operational commands. CTAs are short, confident, and specific. Microcopy explains the next action without filler.

Example lines:
- “Lock in. The dead are already moving.”
- “Type clean. Leave the scoreboard smoking.”

### Wordmark & Logo
The mark is a compact hazard-shield icon: a squared zombie jaw inside a split target reticle, with one mint “bite” cut into the perimeter. The wordmark uses a custom condensed uppercase treatment with a deliberately offset “A” crossbar; it should never be represented as a plain default-font name.

### Signature Brand Color
**Toxic Mint — #B9FF72**. It is the phosphor signal of a functioning console and the visual reward for precise typing.

## Style Decisions
- Keep the game interface dark, high-contrast, and operational rather than glossy or neon-futurist.
- Use generated art for the prominent zombie/arena visual, while keeping typed words and metrics crisp HTML for accessibility and responsiveness.
- The homepage is the game: no marketing landing-page detour before the player can enter a match.
